#숫자 n을 입력받1부터 n까지의 정수를 2진수, 8진수, 16진수로 변환하여 출력

#예시 답안
def print_formatted(number):
    # your code goes here
    n = int(len(bin(number)[2:]))
    for i in range(number):
        a = "{1:>{0}} {2:>{0}} {3:>{0}} {4:>{0}}".format(n,i+1, oct(i+1)[2:], hex(i+1)[2:].upper(), bin(i+1)[2:])
        print(a)

if __name__ == '__main__':
    n = int(input())
    print_formatted(n)
