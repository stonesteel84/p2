'''
s = input()

print(len(s))
if(0<len(s) and len(s) <1000):
    print("OK")

    if(s.isalnum() == True): # 공백처리도 해줘야
        s = s.title()
        print(s)

    else:
        print("FAIL")
    
'''

#예시 답안
def solve(s):
    i = ' '    # 단어의 첫 글자인지 판별하기 위한 변수
    result = ""
    for ch in s:
        if(i==' ' and ch >= 'a' and ch <= 'z'):  # 단어의 첫 글자이고 소문자 이면
						result = result + chr(ord(ch)-32)    # 대문자로 바꾼다.
        else: 
						result = result + ch
        i = ch
    return result

if __name__ == '__main__':
    s = input()
    result = solve(s)
    print(result)

## Capitalize() 함수를 사용할 경우
## 첫번째 글자는 대문자로, 나머지 글자는 소문자로 바껴 문제의 조건과 맞지 않습니다.